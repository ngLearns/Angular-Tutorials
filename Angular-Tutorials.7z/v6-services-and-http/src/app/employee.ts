export interface IEmployee {
    id: number,
    name: string,
    age: number
}